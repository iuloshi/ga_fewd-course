$(document).ready(function(){
	$("#hamburger").click(function(){
		// alert("hi");
		$("#innernav").slideToggle();
	});
});