There are 3 Google Fonts being used. "Source Sans Pro", "Oswald", and "Merriweather".
 
body
Source Sans Pro
20px;
 
"Startup Matchmaker"
#FFFF00;
Merriweather
30px;
 
nav
"Designers", "Developers" - Oswald
 
"Because two brains taste are better than one."
background color #C6C6C6;
Merriweather
25px
italic
 
banner (div with "coworking background image)
box-shadow: 0 0 5px rgba(0, 0, 0, 0.75) inset;
- inset puts the box shadow inside of the 
 
blurb
 width: 34%;
padding: 4%;
 
callout boxes
padding: 2% 3%;
width: 27.3333%;
- NOTE: if you try to add a border, you will go beyond 100%. You can acheive a "border" effect with an inset box shadow.
- box-shadow: -1px 0 0 rgba(0, 0, 0, 0.15) inset; width: 34%;